#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

RICHIESTA:
    Si crei una funzione che prenda in input una lista di stringhe ed un numero k positivo,
    l'idea e di creare e ritornare una lista ordinata di stringhe, ove abbiamo rispetto alle
    stringhe iniziali solo quelle che hanno almeno un carattere ripetuto k volte
    
ATTENZIONE:
    - Vietato usare il metodo sort e la funzione sorted 
      (TROPPO FACILE ALTRIMENTI :) ) 
    
    - La funzione deve essere case sensitive ovvero distinguere caratteri minuscoli
      da maiuscoli
    
ES:
    
    
    Dato in input:
        
        ["ciao","balena","cocciuto","sinossi","aereoplano","Bidone","lezione",
         "cicala","serpente","riccio","elefante","bieta","carota","polo","pollo"]
        
        2
        
    Output:
        ['aereoplano', 'balena', 'carota', 'cicala', 'cocciuto', 'lezione', 
         'pollo', 'polo', 'riccio', 'sinossi']
        
        
        
    Dato in input:
        
        ["ciao","balena","cocciuto","sinossi","aereoplano","Bidone","lezione",
         "cicala","serpente","riccio","elefante","bieta","carota","polo","pollo"]
        
        3
        
    Output:
        ['cocciuto','elefante','serpente','sinossi']

"""

def ordina_stringhe(lista_stringhe):
    lista_ordinata = []
    while len(lista_stringhe) != 0:
        minimo = lista_stringhe[0]
        for index in range(1,len(lista_stringhe)):
            if lista_stringhe[index] < minimo:
                minimo = lista_stringhe[index]
        lista_stringhe.remove(minimo)
        lista_ordinata += [minimo]
    return lista_ordinata



def riordina_k(lista_stringhe,k):
    new_list = []
    for word in lista_stringhe:
        ok=False
        for char in word:
            if word.count(char) == k:
                ok=True
                break;
        if ok==True: new_list += [word]
        
    return ordina_stringhe(new_list)


print(riordina_k(["ciao","balena","cocciuto","sinossi","aereoplano","Bidone","lezione",
         "cicala","serpente","riccio","elefante","bieta","carota","polo","pollo"], 1))

 
    
    
    
    
    

