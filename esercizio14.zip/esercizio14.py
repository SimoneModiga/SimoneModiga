#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

RICHIESTA:
    Si crei una funzione che prenda in input una lista di stringhe ed un numero k positivo,
    l'idea e di creare e ritornare una lista ordinata di stringhe, ove abbiamo rispetto alle
    stringhe iniziali solo quelle che hanno almeno un carattere ripetuto k volte
    
ATTENZIONE:
    - Vietato usare il metodo sort e la funzione sorted 
      (TROPPO FACILE ALTRIMENTI :) ) 
    
    - La funzione deve essere case sensitive ovvero distinguere caratteri minuscoli
      da maiuscoli
    
ES:
    
    
    Dato in input:
        
        ["ciao","balena","cocciuto","sinossi","aereoplano","Bidone","lezione",
         "cicala","serpente","riccio","elefante","bieta","carota","polo","pollo"]
        
        2
        
    Output:
        ['aereoplano','balena','carota','cicala','cocciuto','elefante','lezione',
         'pollo','riccio','serpente','sinossi',"polo"]
        
        
        
    Dato in input:
        
        ["ciao","balena","cocciuto","sinossi","aereoplano","Bidone","lezione",
         "cicala","serpente","riccio","elefante","bieta","carota","polo","pollo"]
        
        3
        
    Output:
        ['cocciuto','elefante','serpente','sinossi']

"""



 
    
    
    
    
    

