#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

Supponiamo di avere un file che nella sua formattazione includa caratteri ASCII
negli esempi sfrutteremo il file 7.txt il cui contenuto è:
  
[    
Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, 
sed diam nonumy eirmod tempor 
invidunt ut labore et dolore 


magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam 
et justo duo dolores et ea rebum!
Stet clita kasd gubergren, no sea 
takimata sanctus est Lorem ipsum dolor 
sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam 
nonumy eirmod tempor invidunt ut labore 
et dolore magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam et justo 
duo dolores et ea rebum. Stet clita kasd 
gubergren, no sea takimata sanctus est Lorem 
ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam nonumy eirmod 
tempor invidunt ut labore et dolore magna aliquyam erat, 
sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum! 
Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   

Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio 
dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait 
nulla facilisi. Lorem ipsum dolor sit amet,
    
    
]
Richiesta:
    
    
 a) Creare una funzione che si prenda in input 2 argomenti: il file da criptare ed il file
    con le regole di criptazione/decriptazione, la funzione dovrà estrapolare le regole di
    criptazione dal secondo file dato, tale file presenta delle coppie carattereX=carattereY
    e in tale fase di criptazione il carattereX viene trasformato nel carattereY, non
    bisogna sovrascrivere il file originale da criptare ma crearne uno nuovo di nome
    criptato.txt.
 b) Creare una seconda funzione che prenda in input 2 argomenti: il file da decriptare ed 
    il file con le regole di criptazione/decriptazione, la funzione dovrà estrapolare le regole
    di decriptazione dal secondo file dato, tale file presenta delle coppie
    carattereX=carattereY e in tale fase di decriptazione il carattereY viene trasformato
    nel carattereX, in questo caso il file da decriptare e un file precedentemente criptato
    e di conseguenza bisognerà creare un nuovo file di nome decriptato.txt in cui mettere
    il contenuto decriptato.
    
    
    Il file di criptazione/decriptazione fa da chiave in una emulazione scarna della
    crittografia simmetrica, difatti è come una chiave che cripta e decripta tramite
    le regole di traduzione al suo interno, il file si chiama fileChiaveSimmetrica.txt
    
    Il file da criptare e decriptare ha un contenuto pari a quello sopra citato tra
    parentesi quadre.
    
    ATTENZIONE:
        non tutti i caratteri sono nel file di traduzione, quindi alcuni si lasciano
        cosi come sono
    
    
"""    

    
    
    
    
    
    