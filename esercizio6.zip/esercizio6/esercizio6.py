#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

Supponiamo di avere un file che nella sua formattazione includa caratteri ASCII
negli esempi sfrutteremo il file 6.txt il cui contenuto è:
  
[    
Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, 
sed diam nonumy eirmod tempor 
invidunt ut labore et dolore 


magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam 
et justo duo dolores et ea rebum!
Stet clita kasd gubergren, no sea 
takimata sanctus est Lorem ipsum dolor 
sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam 
nonumy eirmod tempor invidunt ut labore 
et dolore magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam et justo 
duo dolores et ea rebum. Stet clita kasd 
gubergren, no sea takimata sanctus est Lorem 
ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam nonumy eirmod 
tempor invidunt ut labore et dolore magna aliquyam erat, 
sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum! 
Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   

Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio 
dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait 
nulla facilisi. Lorem ipsum dolor sit amet,
    
    
]
Richiesta:
    
    Creare una funzione che apra un file di testo nel nostro caso il 6.txt che contiene
    esattamente quanto riportato sopra tra le parentesi quadre (ESCLUDENDO LE PARENTESI QUADRE
    DAL CONTENUTO), e di esso ci va a contare:
        - il numero di linee
        - il numero di parole
        - il numero di caratteri
    Queste 3 informazioni dovranno essere stampate con questo formato:
        
        "Il file 6.txt ha X linee, Y parole, Z caratteri"
    
    ATTENZIONE:
        Nel contare i caratteri considerare anche eventuali spazi bianchi, a capi, tab.
        (questo per ricordarsi di non snobbare ciò che non si vede)
        Nel contare le parole è bene dire che una parola è una sequenza di caratteri
        delimitata da spazi bianchi, non confondere una parola con sequenze di escape o 
        punteggiatura
    
    
    
"""




    
    
    
    
    
    
    
    
    
    
    
    




