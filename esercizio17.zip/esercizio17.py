#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

RICHIESTA:
    
    Creare una funzione che prenda in input una stringa di N caratteri, e che
    sfruttando la ricorsione ritorni una lista di tutte le permutazioni possibili
    di tali caratteri N della stringa iniziale, compresa essa nella lista.
    
    
    Tips:
        - Informarsi su cosa siano le permutazioni, e dunque stare attenti all'
          input di una stringa di N caratteri che dovrà generare una lista di 
          N! stringhe, tutte permutazioni (quindi riordinamenti) possibili di 
          tale stringa
          
ES:
    Se la stringa in input è: "abc", qundi N=3
    
    Output:
        ["abc","acb","bca","bac","cab","cba"], quindi N! = 3*2*1 = 6 elementi
    
    
ATTENZIONE:
    L'ordine delle stringhe interne non importa    
    
    
"""