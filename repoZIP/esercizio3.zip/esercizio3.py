#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

Assumiamo di lavorare con tabelle, ogni tabella è composta da righe e colonne,
essa sarà implementata come lista di dizionari, es:
  
--------------------------------------------------------------------------------------   
| Nome    |   Cognome   |   Telefono   |  Azienda  |  Codice Impiegato  | Stipendio  |
--------------------------------------------------------------------------------------
| Marco   |  Paletta    | 3927192931   | Tech.Inc  |       98142        |    1320    |
| Giulio  |  Ramos      | 4427792001   |   Arzos   |       12719        |    1500    |
| Anna    |  Forsi      | 3955592725   | Gecos.Co  |       33342        |    1520    |
| Mario   |  Norci      | 1235782721   | Gecos.Co  |       71628        |    1200    |
| Alex    |  Beton      | 3826412025   |  Arzos    |       77168        |    2000    |
| Luigi   |  Borsi      | 4527199925   | Tech.Inc  |       65377        |    1800    |
| Giulia  |  Tordi      | 6777183409   | Tech.Inc  |       64441        |    1850    |
| Mauro   |  Rossi      | 6788090912   |  Arzos    |       99091        |    1499    |
| Maria   |  Fendi      | 8991882342   | Heart.Inc |       49627        |    2400    |
--------------------------------------------------------------------------------------

[{"Nome":"Marco","Cognome":"Paletta","Telefono":3927192931,"Azienda":"Tech.Inc",
 "Codice Impiegato":98142,"Stipendio":1320},{"Nome":"Giulio","Cognome":"Ramos",
 "Telefono":4427792001,"Azienda":"Arzos","Codice Impiegato":12719,"Stipendio":1500},
 {"Nome":"Anna","Cognome":"Forsi","Telefono":3955592725,"Azienda":"Gecos.Co",
  "Codice Impiegato":33342,"Stipendio":1520},{"Nome":"Mario","Cognome":"Norci",
  "Telefono":1235782721,"Azienda":"Gecos.Co","Codice Impiegato":71628,"Stipendio":1200},
  {"Nome":"Alex","Cognome":"Beton","Telefono":3826412025,"Azienda":"Arzos",
   "Codice Impiegato":77168,"Stipendio":2000},{"Nome":"Luigi","Cognome":"Borsi",
    "Telefono":4527199925,"Azienda":"Tech.Inc","Codice Impiegato":65377,"Stipendio":1800},
   {"Nome":"Giulia","Cognome":"Tordi","Telefono":6777183409,"Azienda":"Tech.Inc",
    "Codice Impiegato":64441,"Stipendio":1850},{"Nome":"Mauro","Cognome":"Rossi",
    "Telefono":6788090912,"Azienda":"Arzos","Codice Impiegato":99091,"Stipendio":1499},
    {"Nome":"Maria","Cognome":"Fendi","Telefono":8991882342,"Azienda":"Heart.Inc",
     "Codice Impiegato":49627,"Stipendio":2400}]
  
    
Richiesta:
    
    Creare una funzione che prenda in input un codice impiegato, il nome di una delle
    colonne della tabella e un valore X che sarà il nuovo valore della colonna X in 
    corrispondenza della riga che ha quel codice impiegato, e che prenda in input la
    tabella
    
    Bisogna controllare che il codice impiegato dato sia valido e che il nome della colonna
    sia coerente con uno di quelli esistenti
    Inoltre bisognerà controllare che il nuovo valore da dare alla colonna rispetto
    alla riga scelta sia valido per quella colonna.
    (Se ad esempio la colonna è il numero di telefono, allora non si accetteranno stringhe)
    
    ATTENZIONE:
        può cambiare lo stesso codice impiegato
    
    
"""

    
    
    
    

