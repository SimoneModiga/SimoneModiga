#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga


RICHIESTA:
    Creare una funzione che prenda in input un path del filesystem, sfruttando la ricorsione
    bisogna stampare tutti i files e le directory che vi sono all'interno ed inoltre 
    riportare il numero di files e dirs trovate.
    
    
ATTENZIONE:
    Solo se siete su sistema Linux:
        - (Ignorare directory che iniziano con '.' o '..')
        - (Ignorare in generale file nascosti che iniziano con '.')
        
Tip:
    Per riuscire nell'impresa bisogna importare il modulo os
    


SCRIVERE UN ESEMPIO UNA VOLTA IMPLEMENTATA LA SOLUZIONE


"""

