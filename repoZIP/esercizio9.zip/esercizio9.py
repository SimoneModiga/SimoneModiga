#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: Simone Modiga



Un albero binario è una struttura che ricorda un albero rovesciato, nel dettaglio
è una struttura a grafo radicato, esso è fatto infatti di nodi e archi di collegamento
ma disposti con certo criterio, ovvero abbiamo un nodo, detto root (radice), e da li
partono le ramificazioni verso nodi sottostanti detti figli. La regola è che un nodo 
può avere 0,1 oppure 2 nodi figli e basta, si parte sempre da un'unico nodo radice e si 
finisce con i nodi foglia ovvero nodi senza figli. Possiamo dunque dire che un nodo
ha al massimo un figlio SX (sinistro) e DX (destro). Quando un nodo non ha nodi figli
o ne ha solo 1, lo spazio vuoto lo si può interpretare come None (nullo). 
Assumiamo nel nostro caso che un nodo ha un valore intero positivo come identificatore.
ES:
    
    
Tree 1:
    
                10
               /  \
             2     4
           /  \     \
         99   5      3
       
         
Tree 2:
    
                    1
                   /
                  22
                /    \
               9     8
                      \
                      14
                      
Tree 3:
    
                  80
                /    \
              55     78
             /  \   /  \
            3  12  5   44
             \        /
              2      42
              
              
Tree 4:
    
                     17
                   /    \
                  45     13
                        /  \
                       22  55
                          /
                         14
                        /  \
                       2    1
                           


Richiesta:
    
    Viene chiesto di sfruttare la programmazione ad oggetti che il Python consente,
    per modellare un modo di rappresentazione di tali alberi binari, in modo tale
    da poter sfruttare tale struttura per molteplici esercizi futuri. Quindi tale
    struttura consentira di poter rappresentare un qualunque albero binario. Per 
    prova usare la struttura creata per rappresentare i 4 alberi binari di esempio
    sopra riportati (le contro prove per capire che tutto funzioni, saranno possibili
    quando veranno fatti esercizi di visita ai nodi degli alberi, sfruttando la 
    ricorsione su tale implementazione, che verrà comunque spiegata e potrà essere
    o meno uguale alla mia implementazione proposta)

    ATTENZIONE: si chiede anche di implementare nella struttura un meccanismo di 
    rappresentazione del singolo nodo, con i nodi figli se presenti o meno, chiaramente
    essendo in ambito di classi Python per fare ciò bisogna sfruttare il metodo speciale
    __str__


"""




