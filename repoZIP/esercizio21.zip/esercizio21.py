#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga



RICHIESTA:
    Creare una funzione che prenda in input una lista di nomi cognomi L strutturata come
    segue:
        
        L = ["Nome Cognome","Nome Cognome",...]
    
    L'output dovrà essere la lista ordinata rispetto alla lunghezza dei cognomi in 
    maniera crescente, in caso di parità ordinare in maniera lessicografica 
    rispetto al Cognome
        
        
ES:
        
    Input:
        L = ["Leo Fermi", "Sandra Robby","Ugo Norimbergo","Alex Forti","Giulio Asserto",
             "Mark Bocci","Sandro True"]
        
    Output:
        L = ["Sandro True","Mark Bocci","Leo Fermi","Alex Forti","Sandra Robby",
             "Giulio Asserto","Ugo Norimbergo"]
    
"""