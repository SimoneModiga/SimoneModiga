#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

RICHIESTA:
    Creare una funzione che prenda in input 2 dizionari X e Y. La funzione dovrà fare l'intersezione
    delle chiavi del dizionario X ed Y e mettere il risultato in un insieme, di seguito la funzione dovrà
    fare l'unione dei valori dei due dizionari X e Y e mettere il risultato in una tupla. Stampare
    in fine l'insieme delle chiavi e la tupla dei valori
    
ES:
    diz1 = {"chiave1":12,"palla":13,"palma":5,"osiride":19,"nave":17}
    diz2 = {"palma":17,"koala":99,"serpente":3,"cane":165,"nave":18,"palla":23}
    
    Output:
        #insieme di chiavi
        {"palla","palma","nave"}
        
        #tupla di valori
        (3, 99, 5, 165, 12, 13, 17, 18, 19, 23)

"""

