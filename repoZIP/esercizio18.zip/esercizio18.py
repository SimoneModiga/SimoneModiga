#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga


ATTENZIONE:
    Per poter svolgere tale esercizio su alberi e ricorsione è bene usare la soluzione
    dell'esercizio 9, di codifica di un albero binario qualunque, che riporta un meccanismo
    di rappresentazione di un albero binario e dunque rispetto a tale struttura la soluzione
    dovrà essere tarata. In generale vi sono piu' modi di rappresentare un albero binario
    ma quello riportato su cui ci baseremo è il migliore, dunque avere stessa struttura 
    permette di portare a termine soluzioni adatte alla richiesta di tale esercizio
    (MORALE DELLA FAVOLA PER I PIGRI A CUI NON PIACE LEGGERE "TRA CUI ANCHE ME"
     DARE UNA SOLUZIONE TARATA SUL MECCANISMO DI RAPPRESENTAZIONE DELL'ALBERO BINARIO
     QUINDI SFRUTTARLA, TALE IMPLEMENTAZIONE SITUA COME SOLUZIONE ALL'ESERCIZIO 9)
     
     
     
RICHIESTA:
    
    Si chiede di sfruttare la soluzione dell'esercizio 9 per creare 1 o piu'
    alberi binari radicati dunque in un nodo radice (vedere lezione esercizio9 su 
    come si fa), e poi creare una funzione che prende in input un nodo radice,
    cui abbiamo radicato precedentemente un albero binario, inoltre la funzione deve
    prendere in input un numero intero positivo diverso da 0, quindi K>0. L'idea è quella
    di stampare solo i nodi dell'albero di cui sommando gli identificatori dei figli 
    ottengo un numero <=K. 
    
    ATTENZIONE: Non vanno stampati i nodi foglia, per i nodi NON FOGLIA l'eventuale
    None vale 0
    
    
    
ES:
        
    
Tree 1:
    
                10
               /  \
             2     4
           /  \     \
         99   5      3  
         
         
k=10
        
Output:
    Nodo: 10  - Figli Sx: 2 Dx: 4
    Nodo: 4  - Figli Sx: None Dx: 3
    
    
    
Tree 2:
    
                10
               /  \
             2     4
           /  \     \
         99   5      3   
                   /   \
                  10   20
                         \
                           23
                           
k=30                           
        
Output:
    Nodo: 10  - Figli Sx: 2 Dx: 4
    Nodo: 4  - Figli Sx: None Dx: 3
    Nodo: 3  - Figli Sx: 10 Dx: 20
    Nodo: 20  - Figli Sx: None Dx: 23
    
    
    
    
        
    
"""