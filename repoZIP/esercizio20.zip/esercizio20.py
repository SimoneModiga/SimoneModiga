#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga



RICHIESTA:
    Creare una funzione che prenda in input un numero, di questo numero bisognerà
    trovare il numero minimo e poi massimo che posso ottenere riordinando le cifre
    del numero dato in input GESTENDO COME DA ESEMPIO GLI ZERI, fatto ciò il 
    risultato sarà la differenza tra il massimo e il minimo
    
    
ES:

    1) Input: 972882, allora il minimo sarà 227889, il massimo 988722
    
       Output: 760833


    2) Input: 3320707, allora il minimo sarà 23377, il massimo 7733200
    
       Output: 7709823

    3) Input: 90010, allora il minimo sarà 19, il massimo 91000
    
       Output: 90981
     

    
"""