#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

Supponiamo di avere un file che nella sua formattazione includa caratteri ASCII
negli esempi sfrutteremo il file 8.txt il cui contenuto è:
  
[    
Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, 
sed diam nonumy eirmod tempor 
invidunt ut labore et dolore 


magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam 
et justo duo dolores et ea rebum!
Stet clita kasd gubergren, no sea 
takimata sanctus est Lorem ipsum dolor 
sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam 
nonumy eirmod tempor invidunt ut labore 
et dolore magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam et justo 
duo dolores et ea rebum. Stet clita kasd 
gubergren, no sea takimata sanctus est Lorem 
ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam nonumy eirmod 
tempor invidunt ut labore et dolore magna aliquyam erat, 
sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum! 
Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   

Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio 
dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait 
nulla facilisi. Lorem ipsum dolor sit amet,
    
    
]
Richiesta:


    Creare una funzione che prenda in input un file che contenga esattamente il
    contenuto sopra citato tra le parentesi quadre, ed una lista di parole (parole che 
    è possibile trovare in tale file), la funzione dovrà creare un nuovo file di nome
    filtrato.txt che rispetto all'originale conterrà al posto delle parole presenti
    nella lista, le loro relative lunghezze, ad esempio:
        se la parola nella lista è "aereo" nel nuovo file verrà rimpiazzata da 5
        
    


"""    



