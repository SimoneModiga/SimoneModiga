#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

RICHIESTA:
    Data una lista di numeri ordinata L ed un numero k, andare ad implementare una binary
    search di k in L, ritornando True se c'è, False altrimenti
    
    Tips:
        - informarsi su cosa sia la binary search di un valore k in una lista
          di numeri ordinata L
        - è preferibile usare una ricorsione
  
    
  
ES:
    
    L = [10,23,25,26,33,45,99,100,103,107,120]
    k = 99
    
    Output:
        True
    
  
"""