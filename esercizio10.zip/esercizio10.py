#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga


ATTENZIONE:
    Per poter svolgere tale esercizio su alberi e ricorsione è bene usare la soluzione
    dell'esercizio 9, di codifica di un albero binario qualunque, che riporta un meccanismo
    di rappresentazione di un albero binario e dunque rispetto a tale struttura la soluzione
    dovrà essere tarata. In generale vi sono piu' modi di rappresentare un albero binario
    ma quello riportato su cui ci baseremo è il migliore, dunque avere stessa struttura 
    permette di portare a termine soluzioni adatte alla richiesta di tale esercizio
    (MORALE DELLA FAVOLA PER I PIGRI A CUI NON PIACE LEGGERE "TRA CUI ANCHE ME"
     DARE UNA SOLUZIONE TARATA SUL MECCANISMO DI RAPPRESENTAZIONE DELL'ALBERO BINARIO
     QUINDI SFRUTTARLA, TALE IMPLEMENTAZIONE SITUA COME SOLUZIONE ALL'ESERCIZIO 9)
     
     
     
RICHIESTA:
    
    Si chiede di sfruttare la soluzione dell'esercizio 9 per creare 1 o piu'
    alberi binari radicati dunque in un nodo radice (vedere lezione esercizio9 su 
    come si fa), e poi creare una funzione che prende in input un nodo radice,
    cui abbiamo radicato precedentemente un albero binario, e sfruttare la ricorsione
    per visitare tutti i nodi presenti, il risultato finale dovrà essere la stampa
    di tutti i nodi del nostro albero (la stampa dell'i-esimo nodo non è altro che una
    sua print visto che vi è un metodo __str__ di rappresentazione adatto)
    
ES:
        
    
Tree 1:
    
                10
               /  \
             2     4
           /  \     \
         99   5      3    
        
# create nodes
root = Nodo(10)
nodo_A1_2 = Nodo(2)
nodo_A1_4 = Nodo(4)
nodo_A1_99 = Nodo(99)
nodo_A1_5 = Nodo(5)
nodo_A1_3 = Nodo(3)

# create tree through the union of the nodes 

root.setNodoSx(nodo_A1_2)
root.setNodoDx(nodo_A1_4)
nodo_A1_2.setNodoSx(nodo_A1_99)
nodo_A1_2.setNodoDx(nodo_A1_5)
nodo_A1_4.setNodoDx(nodo_A1_3)

# ora dare in pasto alla funzione il nodo root di Tree 1, che qui si chiama "root",
il risultato potrebbe essere ordinato diversamente, ma il succo è l'avere li stessi nodi
con stesse stampe.

Output:
    Nodo: 10  - Figli Sx: 2 Dx: 4
    Nodo: 2  - Figli Sx: 99 Dx: 5
    Nodo: 99  - Figli Sx: None Dx: None
    Nodo: 5  - Figli Sx: None Dx: None
    Nodo: 4  - Figli Sx: None Dx: 3
    Nodo: 3  - Figli Sx: None Dx: None



"""

