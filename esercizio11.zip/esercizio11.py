#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga


ATTENZIONE:
    Per poter svolgere tale esercizio su alberi e ricorsione è bene usare la soluzione
    dell'esercizio 9, di codifica di un albero binario qualunque, che riporta un meccanismo
    di rappresentazione di un albero binario e dunque rispetto a tale struttura la soluzione
    dovrà essere tarata. In generale vi sono piu' modi di rappresentare un albero binario
    ma quello riportato su cui ci baseremo è il migliore, dunque avere stessa struttura 
    permette di portare a termine soluzioni adatte alla richiesta di tale esercizio
    (MORALE DELLA FAVOLA PER I PIGRI A CUI NON PIACE LEGGERE "TRA CUI ANCHE ME"
     DARE UNA SOLUZIONE TARATA SUL MECCANISMO DI RAPPRESENTAZIONE DELL'ALBERO BINARIO
     QUINDI SFRUTTARLA, TALE IMPLEMENTAZIONE SITUA COME SOLUZIONE ALL'ESERCIZIO 9)
     
     
     
RICHIESTA:
    
    Si chiede di sfruttare la soluzione dell'esercizio 9 per creare 1 o piu'
    alberi binari radicati dunque in un nodo radice (vedere lezione esercizio9 su 
    come si fa), e poi creare una funzione che prende in input un nodo radice,
    cui abbiamo radicato precedentemente un albero binario, e sfruttare la ricorsione
    per capire quanti livelli esso abbia, quindi lo scopo finale è ritornare un intero 
    positivo che rapp. la profondità massima dell'albero.
    
ES:
        
    
Tree 1:
    
                10
               /  \
             2     4
           /  \     \
         99   5      3    
        
Output:
    3 # numero di livelli che è anche la profondità max
    
    
Tree 2:
    
                10
               /  \
             2     4
           /  \     \
         99   5      3   
                   /   \
                  10   20
                         \
                           23
        
Output:
    5 # numero di livelli che è anche la profondità max
    




"""