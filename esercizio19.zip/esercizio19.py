#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga



RICHIESTA:
    Creare una funzione che prenda in input una lista di numeri e ritorni una lista 
    ordinata di essi in modo crescente, l'ordine si baserà sul numero di buchi che il 
    numero ha, ad esempio:
      - il numero 661, ha esattamente 2 buchi
      - il numero 0 ha esattamente un buco (anche se sembrano 2)
      - il numero 441298 ha esattamente 5 buchi
      - il numero 8 ha esattamente 2 buchi
      
ES:
    lista = [447, 123, 333, 890, 9654, 87123]
    
    Output:
        lista_out = [123, 333, 447, 87123, 9654, 890]
    
    
    
   lista = [8, 121, 41, 66]
    
    Output:
        lista_out = [121, 41, 8, 66]
        
        
        
    lista = [100, 888, 1660, 11]
    
    Output:
        lista_out = [11, 100, 1660, 888]
        
        
        
    
    ATTENZIONE:
        in caso di ordine uguale quindi di equità l'ordine sarà fatto
        rispetto al posizionamento nella lista, rispetto all'ordine in
        cui trovo le cose che sono eque
    
    
"""





























