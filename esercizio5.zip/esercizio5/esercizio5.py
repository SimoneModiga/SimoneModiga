#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

Supponiamo di avere un file che nella sua formattazione includa caratteri ASCII
negli esempi sfrutteremo il file 5.txt il cui contenuto è:
  
[    
Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, 
sed diam nonumy eirmod tempor 
invidunt ut labore et dolore 


magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam 
et justo duo dolores et ea rebum!
Stet clita kasd gubergren, no sea 
takimata sanctus est Lorem ipsum dolor 
sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam 
nonumy eirmod tempor invidunt ut labore 
et dolore magna aliquyam erat, sed diam 
voluptua. At vero eos et accusam et justo 
duo dolores et ea rebum. Stet clita kasd 
gubergren, no sea takimata sanctus est Lorem 
ipsum dolor sit amet. Lorem ipsum dolor sit amet, 
consetetur sadipscing elitr, sed diam nonumy eirmod 
tempor invidunt ut labore et dolore magna aliquyam erat, 
sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum! 
Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.   

Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, 
vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio 
dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait 
nulla facilisi. Lorem ipsum dolor sit amet,
    
    
]
Richiesta:
    
    Creare una funzione che apra un file di testo nel nostro caso il 5.txt che contiene
    esattamente quanto riportato sopra tra le parentesi quadre (ESCLUDENDO LE PARENTESI QUADRE
    DAL CONTENUTO), e che crei e ritorni un dizionario in cui le chiavi sono i-esimi
    caratteri trovati nel testo e in cui i valori sono il numero di ripetizioni di tali
    chiavi. Inoltre stampare il numero di caratteri totali.
    Ad esempio:
        d = {"a":10,"b":20}
        
        Se si ritorna d significa che sono state trovate 10 occorrenze del carattere "a"
        e 20 occorrenze del carattere "b", e i caratteri totali sono 30
    
    
    ATTENZIONE:
        è case sensitive, quindi distingue tra minuscole e maiuscole
        
"""



















