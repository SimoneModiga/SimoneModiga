#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: Simone Modiga

Assumiamo di lavorare con tabelle, ogni tabella è composta da righe e colonne,
essa sarà implementata come lista di dizionari, es:
  
--------------------------------------------------------------------------------------   
| Nome    |   Cognome   |   Telefono   |  Azienda  |  Codice Impiegato  | Stipendio  |
--------------------------------------------------------------------------------------
| Marco   |  Paletta    | 3927192931   | Tech.Inc  |       98142        |    1320    |
| Giulio  |  Ramos      | 4427792001   |   Arzos   |       12719        |    1500    |
| Anna    |  Forsi      | 3955592725   | Gecos.Co  |       33342        |    1520    |
| Mario   |  Norci      | 1235782721   | Gecos.Co  |       71628        |    1200    |
| Alex    |  Beton      | 3826412025   |  Arzos    |       77168        |    2000    |
| Luigi   |  Borsi      | 4527199925   | Tech.Inc  |       65377        |    1800    |
| Giulia  |  Tordi      | 6777183409   | Tech.Inc  |       64441        |    1850    |
| Mauro   |  Rossi      | 6788090912   |  Arzos    |       99091        |    1499    |
| Maria   |  Fendi      | 8991882342   | Heart.Inc |       49627        |    2400    |
--------------------------------------------------------------------------------------

[{"Nome":"Marco","Cognome":"Paletta","Telefono":3927192931,"Azienda":"Tech.Inc",
 "Codice Impiegato":98142,"Stipendio":1320},{"Nome":"Giulio","Cognome":"Ramos",
 "Telefono":4427792001,"Azienda":"Arzos","Codice Impiegato":12719,"Stipendio":1500},
 {"Nome":"Anna","Cognome":"Forsi","Telefono":3955592725,"Azienda":"Gecos.Co",
  "Codice Impiegato":33342,"Stipendio":1520},{"Nome":"Mario","Cognome":"Norci",
  "Telefono":1235782721,"Azienda":"Gecos.Co","Codice Impiegato":71628,"Stipendio":1200},
  {"Nome":"Alex","Cognome":"Beton","Telefono":3826412025,"Azienda":"Arzos",
   "Codice Impiegato":77168,"Stipendio":2000},{"Nome":"Luigi","Cognome":"Borsi",
    "Telefono":4527199925,"Azienda":"Tech.Inc","Codice Impiegato":65377,"Stipendio":1800},
   {"Nome":"Giulia","Cognome":"Tordi","Telefono":6777183409,"Azienda":"Tech.Inc",
    "Codice Impiegato":64441,"Stipendio":1850},{"Nome":"Mauro","Cognome":"Rossi",
    "Telefono":6788090912,"Azienda":"Arzos","Codice Impiegato":99091,"Stipendio":1499},
    {"Nome":"Maria","Cognome":"Fendi","Telefono":8991882342,"Azienda":"Heart.Inc",
     "Codice Impiegato":49627,"Stipendio":2400}]
  
    
Richiesta:
    
    Creare una funzione che prende in input un nome di colonna, un valore X, un
    codice di comando e una tabella.
    Il codice di comando è un numero che vale 0 oppure 1...
    Se vale 0:
        bisogna aggiungere a tutte le righe della tabella questa colonna (se non è già
        esistente), e dargli X come valore di inizializzazione. Se già esistente
        lanciare un ValueError
    Se vale 1:
        bisogna levare da tutte le righe la colonna citata (controllando prima se esista),
        se non esiste lanci un ValueError
    
    
    Controllare anche che il codice di comando sia 0 oppure 1
    
    
"""


                
    
    
    
    
    
    
    
    
    
    
    

